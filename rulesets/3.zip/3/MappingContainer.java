package org.jboss.as.quickstarts.cdi.service;

import java.util.List;

public class MappingContainer {

    private List<String> mapping;

    public List<String> getMapping() {
        return mapping;
    }

    public void setMapping(List<String> mapping) {
        this.mapping = mapping;
    }
}
