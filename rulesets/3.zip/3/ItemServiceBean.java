package org.jboss.as.quickstarts.cdi.service;

import org.jboss.as.quickstarts.cdi.interceptor.MappedFields;

import javax.ejb.Stateless;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;

@Stateless
public class ItemServiceBean {

    @Inject
    private EntityManager em;

    @Inject
    private MapperBean mapper;

    //@Audit
    //@Logging
    public void create(Item item) {
        getMappings();
        mapper.setName("HUI", item);
        em.persist(item);
    }

    //@Audit
    //@Logging
    public List<Item> getList() {
        return em.createQuery("select i from Item i", Item.class).getResultList();
    }

    @Produces
    @MappedFields
    public MappingContainer getMappings() {
        MappingContainer container = new MappingContainer();
        List<String> mapping = new ArrayList<String>();
        mapping.add("XYZHHH");
        container.setMapping(mapping);
        return container;
    }


}
