package org.jboss.as.quickstarts.cdi.service;

import org.jboss.as.quickstarts.cdi.interceptor.Mapping;

import javax.ejb.Stateless;

@Stateless
public class MapperBean {

    @Mapping
    public void setName(String name, Item item) {
        item.setName(name);
    }

}
