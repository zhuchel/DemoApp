package org.jboss.as.quickstarts.cdi.interceptor;

import javax.inject.Inject;
import javax.interceptor.AroundInvoke;
import javax.interceptor.Interceptor;
import javax.interceptor.InvocationContext;
import java.lang.reflect.Field;
import java.util.Arrays;

import org.jboss.as.quickstarts.cdi.service.Item;
import org.jboss.as.quickstarts.cdi.service.MappingContainer;

@Interceptor
@Mapping
public class MappingInterceptor {

    @Inject
    @MappedFields
    private MappingContainer mappingContainer;

    @AroundInvoke
    public Object aroundInvoke(InvocationContext ic) throws Exception {
        String methodName = ic.getMethod().getName();
        if(Arrays.asList(Item.class.getDeclaredFields()).stream().filter(x -> x.getAnnotation(FieldNumber.class) != null).
                filter(x -> x.getName().equals(methodName.toLowerCase().substring(3, methodName.length())) &&
                        mappingContainer.getMapping().contains(x.getAnnotation(FieldNumber.class).value())).findAny()
                .orElse(null) != null) {
            System.out.println("Executing " + ic.getTarget().getClass().getSimpleName() + "." + methodName + " method");
            return ic.proceed();
        }
        return null;
    }
}
